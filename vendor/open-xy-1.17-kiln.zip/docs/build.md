# Build your own firmware

`sdk.py build` statically links every machine in the collection into exact
stock OS 1.2.1, using the [firmware ABI](abi-1.2.1.md), and checks the result.
It runs on Windows x86_64, Apple-silicon macOS and Linux x86_64. To choose among the curated
machines without building, use the [browser builder](builder.md) instead. A
machine reaches the firmware by joining the collection; read the
[caveats](../README.md) before installing.

Commands use `python`; on macOS it is usually `python3`. Building needs only
Python 3.11+, no virtual environment or packages (copying to the device with `device push` also needs comtypes on Windows or the libusb library on macOS and Linux, see [install](#5-install)); the browser preview in
[your first machine](first-machine.md) has its own prerequisites.

## 1. Install the tools

```sh
python sdk.py toolchain fetch
```

It downloads the pinned [toolchain](toolchain.md) for this computer, checks it
and installs it in `local/toolchain`, which every native command uses when
`--toolchain` and `--compiler` are omitted. If you downloaded the zip from the
`toolchain-1` release yourself, install it with
`python sdk.py toolchain fetch --archive <zip>`.

### On Linux

Linux x86_64 has no download yet; build the pinned tools with Docker instead,
from the checkout (it takes several minutes). The tools then run on any
x86_64 distribution with glibc 2.36 or later, such as Debian 12, Ubuntu 24.04,
Fedora 37 or Arch; Ubuntu 22.04 and musl-based distributions such as Alpine
are too old or incompatible. The `z` mount option lets the container read and
write the checkout on SELinux hosts such as Fedora, and changes nothing elsewhere.

```sh
git init local/blackfin-plus-gnu
git -C local/blackfin-plus-gnu fetch --depth 1 https://github.com/deanm1278/blackfin-plus-gnu e4408a15b9be6cd911283f103a1a3f69e9a6b8c0
git -C local/blackfin-plus-gnu checkout FETCH_HEAD
mkdir local/toolchain-build
docker build -t open-xy-toolchain-linux - < tools/gcc/linux.Dockerfile
docker run --rm -u "$(id -u):$(id -g)" -e HOME=/tmp \
  -v "$PWD":/opt/opxy-toolchain/open-xy:ro,z \
  -v "$PWD/local/blackfin-plus-gnu":/opt/opxy-toolchain/fork:z \
  -v "$PWD/local/toolchain-build":/opt/opxy-toolchain/out:z \
  open-xy-toolchain-linux /opt/opxy-toolchain/open-xy/tools/gcc/build-linux.sh \
  /opt/opxy-toolchain/fork /opt/opxy-toolchain/out/blackfin
mv local/toolchain-build/blackfin local/toolchain
```

Native commands then use `local/toolchain` and check every tool against the
`linux-x86_64` pins ([how it is built](toolchain.md#native-tools)).

## 2. Copy the OS from your OP-XY

On an OP-XY running OS 1.2.1, hold COM while switching it on to open te-boot.
It must show "3. dev menu"; if not, enable it with the
[builder's dev menu helper](builder.md#dev-menu). Then:

1. Press track 3 for "3. dev menu"; the next screen is the factory menu.
2. Press track 3 for "3. mtp file transfer (windows)", or track 2 for
   "2. mtp file transfer (mac)", and wait for "mtp mode active". Open the
   device in File Explorer, or in OpenMTP on a Mac (quit Field Kit first).
   On Linux, use track 3 and open the device in your file manager; GNOME
   Files lists it as "OP XY". The file manager needs MTP support (gvfs on
   GNOME or Cinnamon, kio-extras on KDE).
3. Copy the OS into a folder outside every checkout:

```text
stock-1.2.1/
  os.ldr               from /upgrade/firmware/blackfin/bin/os.ldr
```

4. Press track 2 for "2. exit".

If MTP fails to connect or freezes, follow the builder’s
[MTP troubleshooting guide](builder.md#mtp-troubleshooting-on-macos). It offers a fresh OS 1.2.1 setup and separates missing-OS recovery from
a drive format that erases user data.

For example, keep the folder in `%LOCALAPPDATA%/OPXY-SDK/private/` on Windows,
`~/Library/Application Support/OPXY-SDK/private/` on macOS or
`~/.local/share/OPXY-SDK/private/` on Linux. All firmware comes
from your device; the build accepts only the exact stock OS, and an encrypted
`.tfw` is a different format. The stock instrument catalog the build extends,
`op1_factory.json`, is in this repository
([`profiles/opxy-1.2.1/content/op1_factory.json`](../profiles/opxy-1.2.1/content/op1_factory.json)) and is the
default `--stock-content`; pass another folder holding the same file to use
your own copy.

## 3. Add your machine

Start from [your first machine](first-machine.md); `sdk.py new` needs no
preview tools. A machine is a folder that can live anywhere, such as its own
repository. Its `machine.json` names the SDK version it targets (`"sdk": "1.5"`)
and, for a sample engine, the stock sampler it forks; the build gives its
numbers ([identity](api.md#identity), [fields](api.md#registration-boundary)).
Names are saved in presets and never change once published.

Projects save machine numbers, which a build takes from a layout: every package
holds `layout.json`, the numbers its firmware has given out. Pass it to your next
build with `--layout <previous package>/layout.json`, and every machine keeps its
numbers, even after you add or drop others.

Every build command takes the collection:

| Option | Machines built |
| --- | --- |
| `--collection <file>` | The file's `{"path": "<folder>"}` entries, relative to the file. `sdk.py catalog fetch` writes one with every [published machine](catalog.md) |
| `--machine <folder>` | The machine in `<folder>`, after the collection's; repeatable |

A build needs at least one machine; the SDK holds none of its own.

All selected machines share 2032 KiB ([memory and limits](api.md#memory-and-limits));
`compile` shows each machine's share. To make room, list fewer machines in your
own collection file.

`python sdk.py compile --machine <folder> --out <out>` then builds the module
alone, without stock files, and prints each machine's memory use: a quick check
before the full build. Like build outputs, keep `<out>` outside the checkout.
The SDK builds a machine whose `sdk` has its major version and an equal or
older minor version.

## 4. Build

```sh
python sdk.py build --machine <folder> --stock-os <stock-1.2.1>/os.ldr --out <builds>/mine-001
```

The package records its collection, so verifying or exporting it needs no
collection options.

SDK `build` and `compile` keep stock per-voice diagnostic profiling enabled by
default. Pass `--profiling off` to bypass its oscillator, filter and whole-voice
timing bookkeeping, matching firmware generated by the website. Use
`--profiling on` (the default) for development and hardware profiling. The
package records this choice; `verify` rebuilds the same mode.
To collect the measurements, follow [hardware CPU profiling](profiling.md).

This flag leaves the OS clocks, deadline checks, coarse timing counters and
diagnostic transport intact. It does not include private experimental probes.

Use a new `--out` folder for every build, also outside the checkout; a failed
build leaves none behind. The build fails on any check below; on success it
prints its results as JSON, then the files to install from `<out>/candidate/`.

## 5. Install

| File under `candidate/` | Device path |
| --- | --- |
| `os.ldr` | `/os.ldr` |
| `content/op1_factory.json` | `/content/op1_factory.json` |
| `content/display/<machine>.svg`, one per synth | `/content/display/<machine>.svg` |
| `content/presets/<machine>/`, one per instrument (not effect): an init preset and the machine's [own](api.md#presets) | `/content/presets/<machine>/` |
| `content/samples/<machine>/`, for a sample engine shipping [its own samples](api.md#own-samples) | `/content/samples/<machine>/` |

1. Open file transfer as in step 2 and copy the files to the paths above,
   replacing existing files. Keep the device's other content, and never replace
   one of stock's own files other than `os.ldr` and `content/op1_factory.json`:
   stock looks up elements in its own screens and halts at boot when one is
   missing. The build refuses a machine named after stock content
   ([Registration boundary](api.md#registration-boundary)), so none of its files
   lands on one of stock's.
   `python sdk.py device push <out>/candidate` does this instead:
   it backs up each file it replaces, reads
   every copied file back and restores the backups if anything fails, keeping
   them and a record under the private folder. It never writes the boot partition.
   Push copies what it is given and does not check names, because it is also how
   a stock file is put back: a package built before the SDK refused stock names
   can still replace a stock file. Restore it from the backup push keeps.
   On Windows it needs `python -m pip install comtypes==1.4.17`. On macOS and Linux it
   speaks MTP over libusb, which needs only the library (`brew install libusb`, or
   `apt install libusb-1.0-0`), the device in "mtp file transfer (mac)" mode and no
   other app holding it (Field Kit, OpenMTP, Android File Transfer, the browser
   builder); on Linux, a udev rule may be needed for access to the USB device.
   To copy without backups or device readback, pass `--no-backup --no-verify`
   together. This replaces every supplied file and records each write, but
   cannot restore earlier files if interrupted.
2. Press track 2 for "2. exit".
3. Press track 5 for "5. write os to boot partition", keeping the OP-XY on power.
   When "firmware written ok!" appears, switch it off and on.

The firmware writer reads `/os.ldr`, not the upgrade directory. The browser
builder's packages also add each instrument's presets
(`content/presets/<machine>/`: an init preset and the machine's
[own](api.md#presets)).
`module.elf` and `module.bin` are development artifacts, not installable
images. Build commands never write to a device; hardware profiling sends
explicit diagnostic commands but does not install firmware. To select machines and
install through the browser builder's guide instead, export a
[personal kit](builder.md#export-a-kit) of your collection.

## On the device

Each of these cost someone a round of installing:

- **Build from the device's layout.** Pass the `layout.json` of the firmware
  the OP-XY is running, which a builder install leaves at the device's root,
  not one from another build. Otherwise machines get other numbers, and
  projects saved without a [companion](projects.md) open the wrong machines.
- **Write the OS from the boot menu.** A plain restart keeps the old OS. If
  you have left file transfer, hold COM while switching on, then press track 3
  and track 5, and switch off and on after "firmware written ok!".
- **`producer_factory … not registered` is not proof.** The device's log in
  `/logs` shows it at every boot, even when every machine works. A machine
  missing from the menu is what shows the old OS is still running.
- **Copying never deletes.** Presets made for a machine's old controls stay on
  the device and sound wrong until you delete them. Factory presets of machines
  a build leaves out stay too; the firmware hides them
  ([presets](abi-1.2.1.md#presets)).
- **Effects get a quiet send.** An effect receives a much quieter signal than
  a synth's output ([effects](api.md#effects)): one tuned on the host blew out
  at a 1 to 2% send on the device. Test effects on the device at low send
  settings.
- **The stock LFO needs voices or a selected track.** It moves a machine that
  plays no voices only while that machine's track is selected
  ([#238](https://github.com/etcetc000/open-xy/issues/238)).

## What a build checks

| Check | Responsibility |
| --- | --- |
| Stock/tool hashes, exact edit intervals, entry/loader preservation, protected ranges | Shared platform/packager |
| Linked memory bounds, relocations, audio-callback recursion and stack depth, and complete output reconstruction | Shared infrastructure; the selected machines share one module limit |
| Callback layout, registration/name ownership, artwork format | SDK adapters and integration checks |
| Audio arithmetic, sound references, animation sequences and port fidelity | Selected engine's checks |

Host checks do not model device scheduling, interrupts, caches, stock graphics
or recovery, and do not guarantee a recoverable device.

## Release verification

Published packages and browser kits come from the release host named in
[`profiles/toolchains.json`](../profiles/toolchains.json), whose compiler
reproduces the reference bytes ([hosts](toolchain.md#hosts)). There, the
maintainer runs:

```sh
python sdk.py check --native-package <builds>/mine-001 --stock-os <stock-1.2.1>/os.ldr --stock-content profiles/opxy-1.2.1/content
```

It independently rebuilds the package (`sdk.py verify`) and runs the fixture
tests that need the package and stock files; missing inputs or skipped tests
fail. The sample-service fixtures
need a host C++11 compiler (`--host-cxx`, default `g++`) on PATH. A changed
source requires a new package, not a manually changed manifest. Public `check`
ignores inherited fixture variables. A personal build doesn't need this step.
