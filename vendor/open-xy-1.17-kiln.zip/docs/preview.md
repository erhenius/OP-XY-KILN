# Local preview and patch protocol

Browser previews audition synths and drum kits: their controls, alternates
included, their sound and their own screen.
Sample engines and effects use stock pages and stock sample or send processing,
so they have no browser preview; they are checked by the native build.

For a new instrument, follow [Your first machine](first-machine.md). Check the
preview toolchain with `python sdk.py doctor --preview`; custom schema-1 sources
build with `python sdk.py preview --source /path/to/machine --out local/custom-001`.
Custom sources always use local authoring checks and cannot qualify a collection.

Build a machine folder, such as one of the [core machines](https://github.com/etcetc000/open-xy-core-machines) cloned
beside this repository, then serve its authenticated snapshot:

```sh
python sdk.py preview --machine ../open-xy-core-machines/machines/fm2op --out local/preview-001
python tools/serve_harness.py --preview local/preview-001
```

Use `--cxx /path/to/clang++` if Clang is not on PATH, or `--port 8937` if the
server port is occupied. Open http://127.0.0.1:8917/ and play
`A W S E D F T G Y H U J K`, use the on-screen keyboard, or click **Play phrase**.
The first play action enables audio automatically. Escape/Stop all and loss
of window focus release notes. Drag knobs up or down to adjust their values;
hold Shift for finer movement. The sliders beneath them edit the same values.
Focused knobs also accept arrow keys, Page Up/Down and Home/End.
A synth with a [Shift row](api.md#a-synths-shift-row) adds **Shift**, which
holds the row in the screen's header, and **Press**, which switches pages as an
encoder press does, the row following with Shift on.
Volume controls preview playback separately from engine parameters.
**Mute** / **Unmute** silences or restores output without changing Volume or
stopping playback. Muting before the first key or phrase keeps that playback silent.

To change sound or display, edit the C++, rebuild into a fresh directory,
restart the server and reload. Edit `definition.json` for controls, then
rebuild.
The server rejects stale sources at startup; an already running server keeps
its selected snapshot. It serves a file allowlist, never the repository root.

Every preview build runs shared ABI, fixed-memory, input-ownership,
declared-peak, voice-lifecycle and drawing smoke checks. They do not prove
callback correctness or timing; sound correctness is the machine maintainer's
responsibility.

Use **Graphics → Colorful / Grayscale** to inspect the same controls and
animations in both modes. Grayscale uses the machine's declared
[alternate artwork](display.md#grayscale-artwork), or automatic conversion when
none is declared. An already-grayscale original stays unchanged. The selector
does not change audio, control values or saved patches. It starts in Colorful
for authoring; the installer defaults to Grayscale.

## Host behavior

The AudioWorklet runs compiled C++ at 44.1 kHz in 64-sample blocks, with eight
preallocated voices, a 5 ms attack and 120 ms release audition gate. Controls
apply at the next kernel block; retrigger discards pending samples immediately.
The preview does not emulate stock envelopes, filters, LFOs or effects, and
cannot measure Blackfin CPU use. No firmware or device connection is required.

## Drum kits

A kit with its own screen previews like a synth, with the device's keys. Its
module also reports what the device's adapter reads from the kit
([API](api.md#synthesis-drum-kits)): each key's model and eight controls from
`drum_defaults`, each model's name and the labels and count of its controls.
The SDK workbench chooses the model with **Shift + 1 / Model**. On the builder's
machine page:

- The keyboard is the kit's 24 keys, F3 to E5 (canonical 53..76). Each starts as
  the kit sets it up; pressing one selects it, as on the device, and plays it.
- **Machine** chooses the selected key's model, named as the kit names it, with
  its group; the key keeps its controls, as on the device.
- The sliders edit the selected key's controls in the device's steps, 0..127,
  labelled as the model labels them. A slot the model doesn't use is blank and
  doesn't move. Each key keeps its own values while the page is open.
- The screen gets the selected key's `model`, Shift's `choices` for it (its
  group and place, or its model; no choke group), and the `pan`, `level` and
  `pad` fields of a key the kit has not set up: centred, 0 dB, neutral. The stock
  header shows the model's labels and the controls' 0..127 values, where the
  screen doesn't draw its own.
- A hit plays out until the next one: the preview plays one key at a time, and
  a key's release doesn't end it. It doesn't model choke groups, `finished`,
  pan, level, pad fields, scramble, step locks or the transport.

The selected-machines dialog renders the kit's first key, 53, as the kit sets it up.

## Patch format

[controls.mjs](../sdk/browser/controls.mjs) implements validation.
A browser patch contains:

| Field | Value |
| --- | --- |
| `kind` | `opxy-machine-preview` |
| `machine` | Engine ID |
| `parameters` | Exactly the declared normalized controls, finite and in [0, 1] |
| `view` | `routing` (the machine's screen) or `waveform` (an audio scope) |
| `parametersQ31` | Eight words: ordered rounded Q31 controls followed by zeros |

Import validates the Q31 array against the normalized values. Invalid input leaves the current patch unchanged. The UI
limits patch files to 16 KiB. Exported JSON is a browser patch, not an OP-XY
project; exported SVG is a single frame, not executable display code.

## Local automation

After playing a key or phrase, `window.machineLab` provides:

| Method | Input/result |
| --- | --- |
| `getPatch()` / `loadPatch(patch)` | Export/import the same validated format |
| `setParameters(values)` | Complete map of normalized controls |
| `noteOn(midi, velocity = 0.8)` / `noteOff(midi)` | MIDI note 0..127; velocity (0, 1] |
| `panic()` | Stop all voices |
| `getStatus()` | Audio and mute states, backend identity, note counts and output RMS |

The SDK-owned AudioWorklet transport accepts `{type: 'parameters', value}`
(Q31 array), `{type: 'on', note, velocity}`, `{type: 'off', note}` and
`{type: 'panic'}`. It reports readiness/layout or an error. Contributors use the
C++ callbacks; they do not implement this transport themselves.

Preview modules expose ABI version 1, compiled state/buffer sizes, static voice
addresses and lifecycle/render exports, and `opxy_preview_model`, the model a
kit's renders play (other modules ignore it). A kit's module also exports `opxy_drum_defaults(key)`
(the address of nine bytes: the key's model, then its eight controls),
`opxy_drum_model_name(model)`, `opxy_drum_label(model, slot)` and
`opxy_drum_count(model)`; the contract check reads every key and model through them. The runner rejects imports, invalid
layout and a sample-rate mismatch. The manifest binds the WASM, artwork and
source hashes and carries the definition and `machine.json` description that
the workbench page shows. These are host interfaces, not a device upload protocol.

## Checks

Run `python sdk.py check`. For a real-browser check, start a dedicated Chrome with a local debugging port and run
`node tools/check_harness_browser.mjs`. `OPXY_CHROME_PORT` and
`OPXY_PREVIEW_PORT` select its endpoints. It exercises audio, controls, patch
round trips and layout. Its expectations come from the served definition, so it
runs against any preview; screenshots remain in ignored `local/`.
