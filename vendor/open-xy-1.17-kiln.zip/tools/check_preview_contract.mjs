// Firmware-free checks of the shared host contract, independent of a sound's
// reference waveform. Silence and intentional algorithm changes are permitted.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {PreviewEngine} from '../sdk/browser/engine.mjs';
import {PreviewDisplay, outlineFaults} from '../sdk/browser/display.mjs';
import {shownControls} from '../sdk/browser/controls.mjs';

const module = await WebAssembly.compile(readFileSync(process.argv[2]));
// Eight words, or sixteen for a synth with a Shift row (SDK 1.13): its controls, then the row.
const words = new WebAssembly.Instance(module).exports.opxy_parameter_count();
assert.ok(words === 8 || words === 16, 'Eight parameter words, or sixteen with a Shift row');
const engine = new PreviewEngine(module, 44100, Array(words).fill(0));
const display = new PreviewDisplay(module);
// The declared outlines (definition.json resources.display), checked in every frame.
const [paths, points] = process.argv.slice(3, 5).map(Number);
const outlines = new Set();
const memory = engine.api.memory.buffer, displayMemory = display.api.memory.buffer;
assert.equal(engine.blockFrames, 64);
assert.equal(engine.parameterCount, words);
assert.equal(Boolean(display.shiftRow), words === 16, 'A Shift row reaches the display exactly when the voice renders one');
assert.equal(memory.byteLength, 2 * 1024 * 1024, 'Fixed preview memory allowance');
assert.equal(displayMemory.byteLength, memory.byteLength, 'Display uses the same allowance');
assert.throws(() => engine.api.memory.grow(1), RangeError);
assert.throws(() => display.api.memory.grow(1), RangeError);
assert.equal(engine.api.opxy_voice_state(engine.voices.length), 0, 'Factory bound');
const samples = new Float32Array(257);
const right = engine.outputChannels === 2 ? new Float32Array(samples.length) : undefined;
const render = (left, rightOutput = right) => engine.render(left, rightOutput);
const silent = left => left.every(value => value === 0);
render(samples);
assert.ok(samples.every(value => value === 0), 'Inactive voices are silent');
assert.ok(!right || silent(right), 'Inactive right channel is silent');
const peak = engine.api.opxy_output_peak_q31();
for (let corner = 0; corner < 16; ++corner) {
  // Every slot at both extremes: the four controls, then their alternates inverted.
  // A Shift row's words follow the same pattern as the alternates.
  const controls = Array.from({length:words}, (_, i) => (corner >> (i & 3) & 1) ^ (i >> 2 & 1) ? 0x7fffffff : 0);
  engine.setParameters(controls);
  for (let voice = 0; voice < engine.voices.length + 2; ++voice) engine.noteOn(48 + voice * 2);
  const pitches = engine.voices.map(voice => Array.from(voice.pitch));
  for (let block = 0; block < 8; ++block) {
    render(samples);
    assert.ok(samples.every(value => Number.isFinite(value)), 'Finite audition output');
    assert.ok(!right || right.every(Number.isFinite), 'Finite right-channel output');
    assert.deepEqual(Array.from(engine.parameters), controls, 'Read-only controls');
    for (const [i, voice] of engine.voices.entries()) {
      assert.deepEqual(Array.from(voice.pitch), pitches[i], 'Read-only pitch');
      assert.ok(voice.output.every(value => Math.abs(value) <= peak), 'Declared output peak');
    }
    // Each position shows its own control, then its first alternate slot.
    const input = shownControls(controls.slice(0, 8), block & 1 ? [4, 5, 6, 7] : [0, 1, 2, 3]);
    const row = words === 16 ? {held: block >> 1 & 1, line: block & 1, values: controls.slice(8)} : null;
    const frame = display.tick(input, 17, corner * 8 + block, 0, false, null, 0, 0, [0, 0, 0, 0], null, {pan: 0, level: 0}, 0, row);
    for (const fault of outlineFaults(frame, paths || 0, points || 0)) outlines.add(fault);
    assert.equal(engine.api.memory.buffer, memory);
    assert.equal(display.api.memory.buffer, displayMemory);
  }
  for (const voice of engine.voices) engine.noteOff(voice.note);
  const release = new Float32Array(8192);
  const releaseRight = right ? new Float32Array(release.length) : undefined;
  render(release, releaseRight);
  assert.ok(engine.voices.every(voice => !voice.active), 'Release completes');
  assert.ok(release.subarray(6000).every(value => value === 0), 'Release ends in silence');
  assert.ok(!releaseRight || silent(releaseRight.subarray(6000)), 'Right release ends in silence');
  engine.noteOn(60); render(samples); engine.panic(); render(samples);
  assert.ok(samples.every(value => value === 0), 'Panic clears voices');
  assert.ok(!right || silent(right), 'Panic clears right channel');
}
// A drum kit's keys and names, as the builder reads them (builder/core.mjs kitKey, kitModel):
// each key's model within the kit and its controls 0..127, each model's name and labels text.
const models = Number(process.argv[5] || 0);
if (models) {
  const api = engine.api, bytes = () => new Uint8Array(api.memory.buffer);
  const text = (address, what) => {
    if (!address) return '';
    assert.ok(address > 0 && address < bytes().length, `${what} lies in the module's memory`);
    const end = bytes().indexOf(0, address);
    assert.ok(end >= 0 && end - address <= 64, `${what} ends within 64 bytes`);
    return new TextDecoder().decode(bytes().subarray(address, end));
  };
  for (let key = 53; key <= 76; ++key) {
    const at = api.opxy_drum_defaults(key) >>> 0;
    assert.ok(at > 0 && at + 9 <= bytes().length, 'Key defaults lie in the module\'s memory');
    const [model, ...controls] = bytes().subarray(at, at + 9);
    assert.ok(model < models, `Key ${key}'s model is one of the kit's ${models}`);
    assert.ok(controls.every(value => value <= 127), `Key ${key}'s controls are 0..127`);
  }
  for (let model = 0; model < models; ++model) {
    text(api.opxy_drum_model_name(model) >>> 0, `Model ${model}'s name`);
    const count = api.opxy_drum_count(model) >>> 0;
    assert.ok(count <= 8, `Model ${model} uses at most eight slots`);
    for (let slot = 0; slot < count; ++slot) text(api.opxy_drum_label(model, slot) >>> 0, `Model ${model}'s label ${slot}`);
  }
}
// A warning, not a failure, while published machines still draw such outlines.
for (const fault of outlines) {
  console.log(`WARNING: display ${fault}; the OP-XY draws streaks from it. ` +
              'Draw a line as a thin closed ribbon with distinct points (docs/display.md#artwork).');
}
console.log('PASS: preview ABI, fixed memory, controls/pitch ownership, peak bounds, lifecycle' +
            (models ? ', kit keys' : '') + ' and drawing smoke checks.');
