"""Per-key sends (resources.padMix): the mixer hooks, the adapter's codes and the build wiring."""
import copy
import json
import os
from pathlib import Path
import subprocess
import tempfile
from types import SimpleNamespace
import unittest

from tooling.adapters import generate_drum_callbacks
from tooling.definitions import validate_definition
from tooling.firmware import active_services
from tooling import native
from machine_fixtures import fixture
import test_drum_voices   # its run_adapter, without collecting its tests twice
import test_drum_preview
from test_sample_services import HOST_CXX

ROOT = Path(__file__).resolve().parents[1]
PLATFORM = ROOT / 'sdk/platform/opxy-1.2.1'
PROFILE = json.loads((ROOT / 'profiles/opxy-1.2.1.json').read_text(encoding='utf-8'))
# The six reviewed sites, as drum_send_hooks.s describes them.
SITES = {'0x8d510bea': ('sdk_drum_send_track', '00e38f5d'),
         '0x8d51c7b2': ('sdk_drum_send_voice_hook', '0adab01148150000'),
         '0x8d510ea8': ('sdk_drum_send_gain_hook', '0ada901100360000'),
         '0x8d511088': ('sdk_drum_send_source_1', '09da901100360000'),
         '0x8d5110ca': ('sdk_drum_send_source_2', '09da901100360000'),
         '0x8d511116': ('sdk_drum_send_own', '30e51200')}
# Stock's loads of the two send buses (8d511096 for FX I, 8d5110da for FX II),
# which the own-amount hook writes into.
BUS_LOADS = {'0x8d511096': '08daca8440a10000', '0x8d5110da': '0bdaca8440a30000'}

SEND_ENGINE = '''#include "core.h"
namespace probe {
inline void initialize(Voice& v, Shared&, opxy::u32 id) { v.owner = id; ++initialized[id]; }
inline void start(Voice&, Shared&, opxy::u32 id) { ++started[id]; }
inline void destroy(Voice&, Shared&, opxy::u32 id) { ++destroyed[id]; }
inline void drum_defaults(opxy::u32 key, opxy::u8* model, opxy::u8* raw) {
    *model = key % 12;
    for (unsigned i = 0; i < 8; ++i) raw[i] = 64;
}
inline void drum_select(Voice&, Shared&, opxy::u32, opxy::u32 model) { captured_model = model; }
inline const char* parameter_name(opxy::u32, opxy::u32) { return "parameter"; }
inline const char* model_name(opxy::u32) { return "model"; }
inline opxy::u32 parameter_count(opxy::u32) { return 8; }
inline void render(Voice&, Shared&, opxy::u32, opxy::Output output, opxy::Parameters, opxy::Pitch) {
    for (unsigned i = 0; i < opxy::block_frames; ++i) output[i] = 1 << 20;
}
}
'''
SEND_DRIVER = r'''#include "voice.cpp"
#include <cstdio>
const opxy::i32* fixture_region;
opxy::i32 captured[8];
opxy::u32 captured_model = 99;
opxy::u32 fixture_pitch[opxy::block_frames], captured_pitch[opxy::block_frames];
opxy::i32 fixture_amplitude[opxy::block_frames];
bool negative_output;
unsigned destroyed[257], initialized[257], started[257];
unsigned bench_rendered[12][128], clock_value;
volatile opxy::i32 sdk_track_octaves[8];
extern "C" const char probe_engine_id[] = "probe";
const char* sdk_drum_title(opxy::u32, opxy::u32) { return "parameter"; }
extern "C" opxy::u32 sdk_benchmark_cycles() { return 0; }
#define CHECK(condition) do { if (!(condition)) { std::fprintf(stderr, "line %d: %s\n", __LINE__, #condition); return 1; } } while (0)
namespace {
void* objects[256];
opxy::i32 offsets[8];
typedef int (*Start)(void*, opxy::u32, opxy::u32, const opxy::i32*, const opxy::i32*);
typedef int (*End)(void*);
typedef int (*Render)(void*, opxy::i32*, const opxy::i32*, const opxy::i32*);
const void* const* table(unsigned id) { return *static_cast<const void* const* const*>(objects[id]); }
void note(unsigned id, unsigned key) {
    reinterpret_cast<Start>(const_cast<void*>(table(id)[5]))(objects[id], key, 100, fixture_region, offsets);
}
void end(unsigned id) { reinterpret_cast<End>(const_cast<void*>(table(id)[0]))(objects[id]); }
void render(unsigned id, const opxy::i32* payload) {
    opxy::i32 output[opxy::block_frames];
    reinterpret_cast<Render>(const_cast<void*>(table(id)[3]))(objects[id], output, payload, offsets);
}
const opxy::i32 kMarked = opxy::i32(42u * 32537631u + 16268815u);
}
int main() {
    for (unsigned i = 0; i < opxy::block_frames; ++i) fixture_amplitude[i] = 0x7fffffff;
    for (unsigned i = 0; i < 8; ++i) offsets[i] = 0x40000000;
    for (unsigned i = 0; i < 256; ++i) CHECK(objects[i] = probe_factory(i, i % 8));
    // In word 6, FILTER and SRR bits on a key the kit set up; in word 0, FX I at 37
    // and FX II at the old code 3 (33).
    namespace p = opxy::platform;
    const opxy::i32 word = 0x00120000 | p::kDrumPadReady;
    const opxy::u32 pair = p::drum_send_pair(p::drum_send_index_of_amount(37), p::drum_send_index_of_code(3));
    opxy::i32 marked[8] = {kMarked, 0, 0, 0, 0, 0, word, 0};
    opxy::i32 unmarked[8] = {0, 0, 0, 0, 0, 0, word, 0};
    p::drum_send_carry(marked, pair);
    p::drum_send_carry(unmarked, pair);
    // A key an SDK 1.9 kit marked keeps whatever stock left in the word: here stock's
    // default kit's last key (0x26660000) and an editor value with its low half,
    // each beside word 0's low bits as stock's builder leaves them (0x1b25).
    opxy::i32 old_default[8] = {kMarked, 0, 0, 0, 0, 0, 0x26660000, 0};
    opxy::i32 old_editor[8] = {kMarked, 0, 0, 0, 0, 0, opxy::i32(199 * 10737418 + 5368709), 0};
    note(1, 53);
    note(2, 54);
    note(3, 55);
    note(4, 56);
    CHECK(probe_drum_send(objects[1]) == 0);       // nothing rendered yet
    render(1, marked);
    render(2, unmarked);
    render(3, old_default);
    render(4, old_editor);
    CHECK(probe_drum_send(objects[1]) == (PAD_MIX ? pair : 0u));
    CHECK(probe_drum_send(objects[2]) == 0);       // a pad the kit has not marked follows
    CHECK(probe_drum_send(objects[3]) == 0);       // nor one it has not set up
    CHECK(probe_drum_send(objects[4]) == 0);
    end(3);
    end(4);
    // A note keeps the codes of its first block's payload: the payload is the
    // pad's, which a later note on the pad replaces.
    render(1, nullptr);
    CHECK(probe_drum_send(objects[1]) == (PAD_MIX ? pair : 0u));
    note(1, 53);
    render(1, nullptr);
    CHECK(probe_drum_send(objects[1]) == 0);
    render(1, marked);
    CHECK(probe_drum_send(objects[1]) == 0);
    note(1, 53);
    render(1, marked);
    // A destroyed handle has no voice: whatever it renders is silence.
    end(1);
    CHECK(probe_drum_send(objects[1]) == 0);
    CHECK(probe_drum_send(objects[5]) == 0);       // never played
    // A stolen handle: its voice went to another note, so the block it renders
    // is silence and follows the track, whatever the voice's new key sends.
    end(2);
    const opxy::u32 other_pair = p::drum_send_pair(p::drum_send_index_of_code(2), p::drum_send_index_of_amount(100));
    opxy::i32 other[8] = {kMarked, 0, 0, 0, 0, 0, p::kDrumPadReady, 0};
    p::drum_send_carry(other, other_pair);
    const opxy::u32 codes = PAD_MIX ? pair : 0u, other_codes = PAD_MIX ? other_pair : 0u;
    note(1, 53);
    render(1, marked);
    note(6, 57); note(7, 58); note(8, 59);         // the other three voices
    note(9, 60);                                   // takes handle 1's, the oldest
    CHECK(probe_drum_send(objects[1]) == 0 && probe_drum_send(objects[9]) == 0);
    render(9, other);
    render(1, marked);
    CHECK(probe_drum_send(objects[9]) == other_codes);
    CHECK(probe_drum_send(objects[1]) == 0);
    end(6); end(7); end(8); end(9);
    if (kChoke) {
        // A same-key choke fades the old voice over two blocks inside its own
        // renders, the second freeing it: that block still sends as its key
        // does; after it, the handle renders silence and follows the track.
        note(10, 60);
        render(10, marked);
        note(18, 60);                              // the same track (2) and key
        render(10, marked);
        CHECK(probe_drum_send(objects[10]) == codes);
        render(10, marked);                        // the fade ends: the voice is freed
        CHECK(probe_drum_send(objects[10]) == codes);
        render(10, marked);
        CHECK(probe_drum_send(objects[10]) == 0);
        render(18, other);
        CHECK(probe_drum_send(objects[18]) == other_codes && probe_drum_send(objects[10]) == 0);
    }
    std::puts("adapter sends ok");
    return 0;
}
'''


def kit(pad_mix=None, sdk='1.10'):
    definition = copy.deepcopy(fixture('probesynth').definition)
    definition['resources'].update(modelCount=12)
    if pad_mix is not None:
        definition['resources']['padMix'] = pad_mix
    return SimpleNamespace(kind='drum', id='probe', prefix='probe', native_name='probe', definition=definition,
                           sdk=sdk)


def run(command, **kwargs):
    hidden = dict(creationflags=subprocess.CREATE_NO_WINDOW) if os.name == 'nt' else {}
    return subprocess.run(command, capture_output=True, text=True, **kwargs, **hidden)


class DrumSend(unittest.TestCase):
    @unittest.skipUnless(HOST_CXX, 'No working host C++ compiler (set OPXY_TEST_HOST_CXX)')
    def test_the_hooks_keep_stock_mixing_and_route_each_keys_share(self):
        source = (PLATFORM / 'drum_send.cpp').read_text(encoding='utf-8')
        for stock, host in (('reinterpret_cast<i32*>(0x11903600)', 'host_sum'),
                            ('reinterpret_cast<const i32*>(0x11b01548)', 'host_voice'),
                            ('reinterpret_cast<i32*>(0x84caa140)', 'host_fx1'),
                            ('reinterpret_cast<i32*>(0x84caa340)', 'host_fx2'),
                            # A stock dbox voice (drumline.hpp): its method table and object index.
                            ('reinterpret_cast<__UINTPTR_TYPE__>(table) == kDboxMethods', 'table == host_dbox_table'),
                            ('dbox_index(static_cast<u32>(reinterpret_cast<__UINTPTR_TYPE__>(object)))',
                             'host_dbox_index(object)'),
                            # The dry: the send slots' effects, the track records and the dry words.
                            ('reinterpret_cast<void* const*>(0x11b01dc0)', 'host_effects'),
                            ('reinterpret_cast<const unsigned char*>(0x84eab39c)', 'host_records'),
                            ('reinterpret_cast<const i32*>(0x84c69700)', 'host_dry_words')):
            self.assertEqual(source.count(stock), 1, stock)
            source = source.replace(stock, host)
        with tempfile.TemporaryDirectory(prefix='drum-send-') as folder:
            folder = Path(folder)
            (folder / 'drum_send.cpp').write_text(source, encoding='utf-8')
            binary = folder / ('drum_send.exe' if os.name == 'nt' else 'drum_send')
            built = run([HOST_CXX, '-std=c++11', '-O2', '-Wall', '-Werror', '-I' + str(folder),
                         '-I' + str(ROOT / 'sdk/include'), '-I' + str(PLATFORM),
                         str(ROOT / 'tests/fixtures/drum_send_mixer.cpp'), '-o', str(binary)], timeout=120)
            self.assertEqual(built.returncode, 0, built.stdout + built.stderr)
            result = run([str(binary)], timeout=60)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    @unittest.skipUnless(HOST_CXX, 'No working host C++ compiler (set OPXY_TEST_HOST_CXX)')
    def test_the_adapter_keeps_each_voices_send_code(self):
        for pad_mix, choke in ((1, 0), (0, 0), (1, 1)):
            with self.subTest(padMix=pad_mix, chokeSameKey=choke):
                driver = SEND_DRIVER.replace('PAD_MIX', 'true' if pad_mix else 'false')
                test_drum_voices.DrumVoices.run_adapter(self, SEND_ENGINE, driver, 4, padMix=pad_mix,
                                                        chokeSameKey=choke)

    def test_definitions_and_versions(self):
        definition = test_drum_preview.DrumPreviewTests.definition(None, "drum")
        for value in (0, 1):
            validate_definition(dict(definition, resources=dict(definition['resources'], padMix=value)), 'drum')
        for value in (2, -1):
            with self.assertRaises(ValueError):
                validate_definition(dict(definition, resources=dict(definition['resources'], padMix=value)), 'drum')
        # With model groups too (CURIO, GALILEO): its Shift row has no group; the groups title the models.
        groups = [{'label': 'TRX', 'count': 7}, {'label': 'EFM', 'count': 5}]
        validate_definition(dict(definition, resources=dict(definition['resources'], padMix=1, modelGroups=groups)), 'drum')
        # The sends come with padMix alone: the editor that sets them is its Shift row.
        for value in (0, 1):
            with self.assertRaises(ValueError):
                validate_definition(dict(definition, resources=dict(definition['resources'], padSend=value)), 'drum')
        synth = copy.deepcopy(fixture('probesynth').definition)
        synth['resources']['padMix'] = 1
        with self.assertRaises(ValueError):
            validate_definition(synth, 'synth')

    def test_a_pad_mix_kit_links_the_mixer_hooks_and_a_plain_kit_does_not(self):
        services = PROFILE['services']
        self.assertEqual(services['drum_sends'], ['padMix', 'drumline_page'])
        with_sends, without = kit(1), kit()
        self.assertIn('padMix', native.service_users([with_sends]))
        self.assertNotIn('padMix', native.service_users([without]))
        self.assertIn('drum_sends', active_services(PROFILE, native.service_users([with_sends])))
        self.assertNotIn('drum_sends', active_services(PROFILE, native.service_users([without])))
        self.assertEqual(native.UNIT_SERVICES['drum_send'], 'drum_sends')
        self.assertEqual(native.UNIT_SERVICES['drum_send_hooks'], 'drum_sends')

    def test_the_profile_reviews_six_call_sites_outside_hardware_loops(self):
        hooks = {p['address']: p for p in PROFILE['patches'] if p.get('service') == 'drum_sends'}
        self.assertEqual(set(hooks), set(SITES))
        for address, (symbol, before) in SITES.items():
            patch = hooks[address]
            self.assertEqual((patch['kind'], patch['symbol'], patch['before'], patch['call']),
                             ('hook', symbol, before, True))
            self.assertEqual(patch['length'], len(before) // 2)
        stubs = (PLATFORM / 'drum_send_hooks.s').read_text(encoding='utf-8')
        for symbol, _before in SITES.values():
            self.assertIn('.global %s' % symbol, stubs)
        # Each stub replays the instruction it replaces: the loop's call, P2's and P1's loads.
        self.assertIn('P0.H = 0x8d51; P0.L = 0xc708;\n    JUMP (P0);', stubs)
        self.assertIn('P2.H = 0x11b0; P2.L = 0x1548;', stubs)
        self.assertIn('P1.H = 0x1190; P1.L = 0x3600;', stubs)
        # The track gain's hook hands C++ the track, then the gain R0 and the step R2
        # (sdk_drum_send_gain(track, gain, step)), and replays P2's load of the sum.
        body = stubs[stubs.index('sdk_drum_send_gain_hook:\n'):]
        self.assertIn('    HOOK_SAVE\n    R1 = R0;\n    P0 = [FP];\n    R0 = [P0 + 8];\n    CALL sdk_drum_send_gain;\n'
                      '    HOOK_RESTORE\n    P2.H = 0x1190; P2.L = 0x3600;\n    RTS;', body[:body.index('.size')])

    def test_each_stub_replays_the_immediate_its_site_held(self):
        # An early hardware test replayed P1 = 0x11900000 where stock loads 0x11903600 (a decimal
        # misread), so every send read another buffer. Decode the reviewed bytes
        # instead of trusting a disassembler's numbers: Blackfin+ `reg = imm32` is
        # 0xdaNN (NN the register: 0..7 R0..R7, 8..13 P0..P5), then the high and low halves.
        names = ['R%d' % i for i in range(8)] + ['P%d' % i for i in range(6)]
        stubs = (PLATFORM / 'drum_send_hooks.s').read_text(encoding='utf-8')
        source = (PLATFORM / 'drum_send.cpp').read_text(encoding='utf-8')
        loads = {}
        for address, (symbol, before) in SITES.items():
            words = [int.from_bytes(bytes.fromhex(before)[i:i + 2], 'little') for i in range(0, len(before) // 2, 2)]
            if words[0] & 0xff00 != 0xda00:
                continue
            register, value = names[words[0] & 0xff], words[1] << 16 | words[2]
            loads[address] = value
            body = stubs[stubs.index(symbol + ':\n'):]
            body = body[:body.index('.size ' + symbol)]
            self.assertIn('%s.H = 0x%04x; %s.L = 0x%04x;' % (register, value >> 16, register, value & 0xffff), body,
                          '%s must replay %s = 0x%08x' % (symbol, register, value))
        self.assertEqual(loads, {'0x8d51c7b2': 0x11b01548, '0x8d510ea8': 0x11903600, '0x8d511088': 0x11903600,
                                 '0x8d5110ca': 0x11903600})
        buses = []
        for before in BUS_LOADS.values():
            words = [int.from_bytes(bytes.fromhex(before)[i:i + 2], 'little') for i in range(0, 8, 2)]
            buses.append(words[1] << 16 | words[2])
        self.assertEqual(buses, [0x84caa140, 0x84caa340])
        for bus in buses:
            self.assertIn('reinterpret_cast<i32*>(0x%08x)' % bus, source)
        # The own-amount hook replays the load it replaces (8d511116: 30e5 1200).
        body = stubs[stubs.index('sdk_drum_send_own:\n'):]
        self.assertIn('    HOOK_RESTORE\n    P0 = [SP + 0x48];\n    RTS;', body[:body.index('.size')])
        # The track hook replaces a relative CALL and must jump to its target.
        from tooling.firmware import decode_branch
        target, call = decode_branch(0x8d510bea, bytes.fromhex(SITES['0x8d510bea'][1]))
        self.assertTrue(call)
        self.assertIn('P0.H = 0x%04x; P0.L = 0x%04x;\n    JUMP (P0);' % (target >> 16, target & 0xffff), stubs)
        # The C++ side reads the same two stock buffers.
        self.assertIn('reinterpret_cast<i32*>(0x%08x)' % loads['0x8d511088'], source)
        self.assertIn('reinterpret_cast<const i32*>(0x%08x)' % loads['0x8d51c7b2'], source)

    def test_the_own_hook_reads_the_dry_where_the_engine_keeps_it(self):
        # The own-amount hook hands the C++ side the engine's frame pointer, which
        # reads FX I's gain [FP-0x8], the dry smoother [FP-0x34] and the main out
        # [SP+0x58] with SP = FP - 0xe4 (test_stock_lays_out_the_dry_as_the_hook_reads_it).
        stubs = (PLATFORM / 'drum_send_hooks.s').read_text(encoding='utf-8')
        body = stubs[stubs.index('sdk_drum_send_own:\n'):]
        body = body[:body.index('.size')]
        self.assertIn('    P0 = [FP];\n    R0 = [P0 + 8];\n    R1 = [P0 + -0x68];\n    R2 = P0;\n'
                      '    CALL sdk_drum_send_own_mix;', body)
        source = (PLATFORM / 'drum_send.cpp').read_text(encoding='utf-8')
        for text in ('kFrameFx1 = -0x8', 'kFrameDrySmoother = -0x34', 'kFrameMainOut = -0xe4 + 0x58',
                     'kRecordBytes = 0xe8, kFx2Knob = 0x5c, kDryMethod = 7', 'kRecords + (14 + s) * kRecordBytes',
                     'reinterpret_cast<void* const*>(0x11b01dc0)', 'reinterpret_cast<const i32*>(0x84c69700)',
                     'in.shift = frame_word<short>(smoother, 8);', 'in.reset = smoother[0xa] != 0;'):
            self.assertEqual(source.count(text), 1, text)
        # Only a track with an own-amount key asks the effects or writes the main out.
        mix = source[source.index('void sdk_drum_send_own_mix(u32 track, i32 level, const unsigned char* frame) {'):]
        self.assertLess(mix.index('drum_send_dry_idle'), mix.index('dry_query'))

    @unittest.skipUnless(os.environ.get('OPXY_TEST_STOCK_OS'), 'Private stock input not supplied')
    def test_stock_lays_out_the_dry_as_the_hook_reads_it(self):
        from tooling.formats import ldr, mapped_offset, sha
        stock = Path(os.environ['OPXY_TEST_STOCK_OS']).read_bytes()
        self.assertEqual(sha(stock), PROFILE['stock_sha256'])
        image = ldr(stock)

        def at(address, length):
            offset = mapped_offset(image, address, length)
            return stock[offset:offset + length].hex()
        expected = {
            0x8d510760: '00e82d00e305666f',   # LINK 0xb4; [--SP] = (R7:4, P5:3); SP += -0x14: SP = FP - 0xe4
            0x8d510cfe: '09dab011881d0000',   # P1 = 0x11b01d88, the slots' effect objects
            0x8d510d06: '31caae218aa30000',   # ... || R2 = [P1 + 0x38]: slot 14's
            0x8d510d5c: 'c9ad6100',           # P1 = [P1 + 0x1c]; CALL (P1): method word 7, the dry query
            0x8d510d6e: '03c80018c3a3d4bb',   # R3 = [P0 + 0x3c]: slot 15's
            0x8d510db6: '31ca8a20c9afe1bb',   # R2 = R1 * R2 (T) || ... || [FP - 0x8] = R1: G1, G1 (1 - d1)
            0x8d510e14: '31ca3820f0af1191',   # R0 = R7 * R0 (T): G2 (1 - d2)
            0x8d510e3a: '04c41060',           # R0 = R2 - R0 (S): D
            0x8d511106: '04cc012039b90000',   # ... || P1 = [FP - 0x34]: the dry smoother
            0x8d51111a: '3ab9',               # P2 = [FP - 0x34]
            0x8d511122: '04cc124438b90380',   # ... || R0 = [P3 ++ P0]: the track's dry word
            0x8d51112a: '31c21820',           # R0 = R3 * R0 (T): D x
            0x8d51113c: '04cc01640ba90000',   # R2 = R0 - R1 (S) || R3 = W[P1 + 0x8] (X)
            0x8d511144: '1a40',               # R2 >>>= R3
            0x8d51114a: '31e51600',           # P1 = [SP + 0x58]: the main out
            0x8d51114e: '04cc1020019c0000',   # R0 = R2 + R0 (S) || R1 = [I0++]: a step every word
            0x8d50e6f6: '256c00daff7fffff00002892',   # P5 += 4; R0 = 0x7fffffff; [P5++] = R0: the dry words
        }
        for address, hexes in expected.items():
            self.assertEqual(at(address, len(hexes) // 2), hexes, hex(address))

    def test_the_send_table_names_kits_that_declare_pad_mix(self):
        plain = kit()
        sending = SimpleNamespace(**dict(vars(kit(1)), prefix='sender', id='sender'))
        with tempfile.TemporaryDirectory() as folder:
            source = generate_drum_callbacks(folder, [plain, sending]).read_text(encoding='utf-8')
        self.assertIn('{sender_vtable, sender_drum_send},', source)
        self.assertNotIn('probe_vtable', source)
        self.assertIn('sdk_drum_send_kit_count = 1;', source)
        with tempfile.TemporaryDirectory() as folder:
            source = generate_drum_callbacks(folder, [plain]).read_text(encoding='utf-8')
        self.assertIn('sdk_drum_send_kit_count = 0;', source)
        machine = SimpleNamespace(**dict(vars(kit(1)), display='drawing'))
        absent = native.absent_symbols(machine)
        # The table's declaration has no assembler name, so the object imports _probe_vtable.
        self.assertEqual(absent['_probe_vtable'], 'kit_absent')
        self.assertEqual(absent['probe_drum_send'], 'kit_absent')
        self.assertNotIn('probe_drum_pad_text', absent)
        machine.definition['resources']['padControls'] = [dict(bits=4, label='TUNE')]
        self.assertEqual(native.absent_symbols(machine)['probe_drum_pad_text'], 'kit_absent')


if __name__ == '__main__':
    unittest.main()
