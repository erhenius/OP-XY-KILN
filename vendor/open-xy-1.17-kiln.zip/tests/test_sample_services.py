"""Native qualification executes the real SDK services with host boundary doubles."""
import os
import shutil
from pathlib import Path
import subprocess
import tempfile
import unittest
from dataclasses import replace
from tooling.adapters import generate_sample_callbacks, generate_screen_order
from tooling.startup import generate as generate_startup
from machine_fixtures import fixture

ROOT = Path(__file__).resolve().parents[1]


def host_compiler():
    """A C++ compiler that builds and runs host programs, or None."""
    compiler = os.environ.get('OPXY_TEST_HOST_CXX', 'g++')
    with tempfile.TemporaryDirectory(prefix='host-cxx-') as folder:
        source, binary = Path(folder) / 'probe.cpp', Path(folder) / ('probe.exe' if os.name == 'nt' else 'probe')
        source.write_text('int main() { return sizeof(unsigned) == 4 && sizeof(void*) >= 4 ? 0 : 1; }\n')
        hidden = dict(creationflags=subprocess.CREATE_NO_WINDOW) if os.name == 'nt' else {}
        try:
            built = subprocess.run([compiler, str(source), '-o', str(binary)], capture_output=True, timeout=60, **hidden)
            return compiler if built.returncode == 0 and subprocess.run([str(binary)], timeout=30, **hidden).returncode == 0 else None
        except (OSError, subprocess.SubprocessError):
            return None


HOST_CXX = host_compiler()


@unittest.skipUnless(HOST_CXX, 'No working host C++ compiler (set OPXY_TEST_HOST_CXX)')
class SampleServices(unittest.TestCase):
    def run_fixture(self, name, extra=()):
        with tempfile.TemporaryDirectory(prefix='sample-services-') as folder:
            binary = Path(folder) / (name + ('.exe' if os.name == 'nt' else ''))
            hidden = dict(creationflags=subprocess.CREATE_NO_WINDOW) if os.name == 'nt' else {}
            if name in ('sample_callbacks', 'benchmark', 'drum_controls', 'presets', 'keyboard_octaves', 'sample_slice_clock'):
                probe = replace(fixture('probesample'), id='probe', identity=dict(engine=46, page=7))
                if name == 'sample_callbacks':
                    probe = replace(probe, definition=dict(probe.definition,
                        resources=dict(probe.definition['resources'], sliceTiming=1)))
                    # A page-2 engine with no services beside it: it plays like the sampler.
                    plain = fixture('probesample')
                    sampler = replace(plain, id='sampler', identity=dict(engine=47, page=2),
                                      definition=dict(plain.definition, resources=dict(voiceCapacity=256)))
                    generate_sample_callbacks(folder, [probe, sampler])
                elif name in ('drum_controls', 'sample_slice_clock'):
                    source = ROOT / 'sdk/platform/opxy-1.2.1' / (
                        'drum_controls_stock.cpp' if name == 'drum_controls' else 'sample_slice_clock.cpp')
                    (Path(folder) / source.name).write_text(source.read_text())
                    shutil.copy(ROOT / 'sdk/platform/opxy-1.2.1/keyboard_octaves.cpp', Path(folder))
                elif name == 'keyboard_octaves':
                    shutil.copy(ROOT / 'sdk/platform/opxy-1.2.1/keyboard_octaves.cpp', Path(folder))
                elif name == 'benchmark':
                    from tooling.benchmark import generate
                    generate(folder, [replace(fixture('probesynth'), id='unfamiliar', identity=dict(engine=46, page=91))])
            if name in ('sample_callbacks', 'benchmark', 'drum_controls', 'presets', 'keyboard_octaves', 'sample_slice_clock', 'startup', 'sample_overview'):
                # Exercise the real tempo readers and assignment bridge with
                # host addresses standing in for stock functions and globals.
                stock = (ROOT / 'sdk/platform/opxy-1.2.1/stock.hpp').read_text()
                stock = stock.replace('typedef __UINTPTR_TYPE__ Address;',
                                      'typedef __UINTPTR_TYPE__ Address;\nAddress host_stock_address(Address);')
                for pointer in ('T*', 'const volatile u32*', 'const volatile unsigned char*'):
                    stock = stock.replace('reinterpret_cast<' + pointer + '>(address)',
                                          'reinterpret_cast<' + pointer + '>(host_stock_address(address))')
                (Path(folder) / 'stock.hpp').write_text(stock)
                if name == 'sample_overview':   # beside the host stock.hpp, which its quoted include then finds
                    (Path(folder) / 'sample_overview.cpp').write_text(
                        (ROOT / 'sdk/platform/opxy-1.2.1/sample_overview.cpp').read_text())
                if name == 'presets':  # beside the host stock.hpp, so their includes reach it
                    for unit in ('presets.cpp', 'registration.hpp'):
                        shutil.copy(ROOT / 'sdk/platform/opxy-1.2.1' / unit, Path(folder) / unit)
            if name == 'screen_order':
                generate_screen_order(folder)
            if name == 'screen_drawing':
                # Copy the unchanged renderer so its quoted stock-header include
                # can resolve to a host boundary double instead of a 32-bit ABI.
                (Path(folder) / 'screen_drawing.hpp').write_bytes(
                    (ROOT / 'sdk/platform/opxy-1.2.1/screen_drawing.hpp').read_bytes())
                (Path(folder) / 'retained_drawing.hpp').write_bytes(
                    (ROOT / 'sdk/platform/opxy-1.2.1/retained_drawing.hpp').read_bytes())
                (Path(folder) / 'screen.hpp').write_bytes(
                    (ROOT / 'tests/fixtures/screen_drawing_host.hpp').read_bytes())
                (Path(folder) / 'amp_envelope.hpp').write_bytes(
                    (ROOT / 'tests/fixtures/amp_envelope_host.hpp').read_bytes())
            if name == 'startup':
                generate_startup(folder, ['first', 'second', 'sampled', 'drawn'], ['effect'], ['sampled', 'drawn'], ['drawn'],
                                 effect_screens=['effect'], player_pages=['player'], control=True)
            # A fixture that includes barrier.hpp supplies host_barrier for the Blackfin SSYNC.
            command = [HOST_CXX, '-std=c++11', '-O2', '-Wall', '-Werror', '-D__builtin_bfin_ssync()=host_barrier()',
                       '-I' + str(folder), '-I' + str(ROOT / 'sdk/include'),
                       '-I' + str(ROOT / 'sdk/platform/opxy-1.2.1'), str(ROOT / 'tests/fixtures' / (name + '.cpp')),
                       *(str(ROOT / path) for path in extra), '-o', str(binary)]
            result = subprocess.run(command, capture_output=True, text=True, timeout=120, **hidden)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            result = subprocess.run([str(binary)], capture_output=True, text=True, timeout=120, **hidden)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_refused_voice_index_gets_an_inert_object(self):
        from tooling.adapters import sample_refusal
        with tempfile.TemporaryDirectory(prefix='sample-refusal-') as folder:
            for name, stereo in (('wide', 1), ('narrow', 0)):
                (Path(folder) / f'refusal_{name}.inc').write_text(sample_refusal(name, stereo), encoding='utf-8')
            binary = Path(folder) / ('refusal' + ('.exe' if os.name == 'nt' else ''))
            hidden = dict(creationflags=subprocess.CREATE_NO_WINDOW) if os.name == 'nt' else {}
            command = [HOST_CXX, '-std=c++11', '-O2', '-Wall', '-Werror', '-I' + folder, '-I' + str(ROOT / 'sdk/include'),
                       str(ROOT / 'tests/fixtures/sample_voice_refusal.cpp'), '-o', str(binary)]
            result = subprocess.run(command, capture_output=True, text=True, timeout=120, **hidden)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            result = subprocess.run([str(binary)], capture_output=True, text=True, timeout=120, **hidden)
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)

    def test_cache_lifetime_capacity_and_browser_deferral(self):
        self.run_fixture('sample_cache')

    def test_keyboard_effective_octave_and_gui_refresh(self):
        self.run_fixture('keyboard_octaves')

    def test_progress_never_takes_over_another_notification(self):
        self.run_fixture('sample_progress')

    def test_saved_settings_tuning_and_trim_bounds(self):
        self.run_fixture("stock_sample")

    def test_drum_registration_preserves_stock_and_rejects_conflicts(self):
        self.run_fixture('drum_machines', ('sdk/platform/opxy-1.2.1/drum_machines.cpp',))

    def test_drum_controls_survive_stock_preset_integer_roundtrip(self):
        self.run_fixture('drum_storage')

    def test_overview_is_read_by_the_worker_and_follows_the_sample(self):
        self.run_fixture('sample_overview')

    def test_preset_scan_hides_factory_presets_of_engines_not_installed(self):
        self.run_fixture('presets')

    def test_callbacks_work_for_another_engine_and_preserve_stock_fields(self):
        self.run_fixture('sample_callbacks', ('sdk/platform/opxy-1.2.1/sample_machines.cpp',))

    def test_pad_shortcuts_clipboard_and_multi_edit(self):
        self.run_fixture('drum_controls', ('sdk/platform/opxy-1.2.1/sample_machines.cpp',))

    def test_slicer_source_preview_matches_timestamp_rate_and_frozen_bounds(self):
        self.run_fixture('sample_preview')

    def test_slicer_clock_uses_frozen_gui_controls_and_machine_rate(self):
        self.run_fixture('sample_slice_clock', ('sdk/platform/opxy-1.2.1/sample_machines.cpp',))

    def test_owned_primary_screen_precedes_stock_overlays(self):
        self.run_fixture('screen_order')

    def test_display_activation_resets_state_and_invalidates_geometry_keys(self):
        self.run_fixture('screen_drawing')

    def test_held_kit_pad_strip_follows_drumlines_frame(self):
        self.run_fixture('drum_hold_strip')

    def test_registration_never_overwrites_and_rechecks_stock_state(self):
        self.run_fixture('registration')

    def test_startup_registers_in_order_and_gates_the_catalog(self):
        self.run_fixture('startup')

    def test_benchmark_forwards_stock_and_only_owned_arbitrary_synths(self):
        self.run_fixture('benchmark')
