async function readPreviewManifest() {
  try {
    const response = await fetch('/preview/manifest.json');
    if (!response.ok) throw new Error('Build the C++ preview, then start the server with --preview. See the README.');
    return await response.json();
  } catch (error) {
    document.getElementById('status').textContent = error.message;
    document.getElementById('audio').disabled = true;
    throw error;
  }
}
const previewManifest = await readPreviewManifest();
const customPreview = previewManifest.kind === 'cpp-browser-custom-preview';
if (customPreview) {
  document.getElementById('preview-mode').textContent = 'Local authoring preview. This audition does not qualify a firmware build.';
}
import { createControls, editedShown, pressedShown, shownControls, VIEWS } from '../sdk/browser/controls.mjs';
const controls = createControls(previewManifest.definition);
const { definition, parameters, positions, defaults, presets, displayValue, makePatch, readPatch, validateParameters, q31 } = controls;
import { renderScreen as renderBase } from './screen.mjs';
import { bindKnob } from './knobs.mjs';
import { createAudioActivation } from './audio-activation.mjs';
import { createOutputMute } from './audio-output.mjs';
import { PreviewDisplay, SvgDisplay, NoteActivity } from '../sdk/browser/display.mjs';
import { selectArtwork } from '../sdk/browser/graphics.mjs';
import { createGraphicsSelector } from './graphics.mjs';
const noteActivity = new NoteActivity();
const renderScreen = (...args) => renderBase(...args, controls, shown, scene?.header, shiftHeld);
const $ = id => document.getElementById(id);
// A synth's Shift row (SDK 1.13): its present entries, each under page i >> 2, position i & 3.
const shiftControls = controls.shift.map((p, i) => ({ p, i })).filter(({ p }) => !p.absent);
const controlId = id => {
  if (!customPreview) return id;
  const main = parameters.findIndex(p => p.id === id);
  return `custom-control-${main >= 0 ? main : 8 + controls.shift.findIndex(p => p.id === id)}`;
};
// Whether the preview shows the Shift row, as holding Shift does on the device: from an
// edit of one of its entries until a control of the page is edited, or while the
// Shift button is on.
let shiftHeld = false;
// Page copy comes from the machine: its definition and machine.json description.
document.querySelector('.instrument-top h1').textContent = definition.name;
document.title = definition.name + ' · Open-XY Machine Workbench';
document.querySelector('.instrument').setAttribute('aria-label', definition.name + ' instrument');
if (previewManifest.description) $('machine-description').textContent = previewManifest.description;
if (!Object.keys(presets).length) document.querySelector('#presets').closest('.side-section').hidden = true;
if (customPreview) {
  $('machine-description').textContent = 'Edit your C++ sound and display, then rebuild to hear and see the change.';
}
// The parameter each control position shows: the one last edited there.
let values = defaults(), view = VIEWS[0], octave = 3, shown = [0, 1, 2, 3];
let artworkChoice = null, graphicsMode = 'colorful';
let visualNotes = 0, display = null, scene = null, displayBackend = null;
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
let context, processor, gain, muteGain, analyser, samples, starting;
let audioBackend = null;
const outputMute = createOutputMute();
const parameterWords = () => q31(values);
const held = new Map(), timers = new Set();
const keys = ['a', 'w', 's', 'e', 'd', 'f', 't', 'g', 'y', 'h', 'u', 'j', 'k'];
const black = new Set([1, 3, 6, 8, 10]);
const status = text => { $('status').textContent = text; };
const send = message => processor?.port.postMessage(message);
const activation = createAudioActivation({
  isReady: () => context?.state === 'running' && Boolean(audioBackend) && !starting,
  enableAudio,
});
const phraseRequest = Symbol('phrase');
function renderMuteButton() {
  const label = outputMute.muted ? 'Unmute' : 'Mute';
  $('audio').textContent = label;
  $('audio').setAttribute('aria-label', label + ' audio');
  $('audio').dataset.muted = String(outputMute.muted);
}
function playbackStatus() {
  if (outputMute.muted) return 'Audio muted';
  return context?.state === 'running' && audioBackend
    ? `Audio on · ${context.sampleRate.toLocaleString()} Hz · 8 preview voices`
    : 'Play a key or phrase to start audio';
}

function addControl(param, position, label, edited) {
  const id = controlId(param.id);
  const item = document.createElement('div');
  item.className = 'control';
  item.dataset.controlPosition = position + 1;
  item.innerHTML = `<label for="${id}">${label}</label><svg id="knob-${id}" class="dial" viewBox="0 0 60 60" role="slider" tabindex="0" aria-label="${label} knob" aria-valuemin="0" aria-valuemax="1" aria-orientation="vertical"><title>Drag up or down to adjust. Hold Shift for fine control.</title><circle class="dial-ring" cx="30" cy="30" r="27"/><circle class="dial-cap" cx="30" cy="30" r="18"/><line id="dial-${id}" x1="30" y1="16" x2="30" y2="23"/></svg><output id="value-${id}" for="${id}"></output><input id="${id}" type="range" min="0" max="1" step="0.001" aria-label="${label}">`;
  $('controls').append(item);
  $(id).addEventListener('input', event => {
    values[param.id] = Number(event.target.value);
    edited();
    update();
  });
  bindKnob($(`knob-${id}`), $(id));
}
for (const [i, param] of parameters.entries()) {
  addControl(param, positions[i], param.label, () => {
    shiftHeld = false;
    shown = editedShown(shown, positions, i, previewManifest.definition.press === 'page');
  });
}
// The Shift row's entries: an edit shows the row on its page, as Shift and that page's encoder do.
for (const { p, i } of shiftControls) {
  addControl(p, i & 3, 'Shift + ' + p.label, () => {
    shiftHeld = true;
    const next = [0, 1, 2, 3];
    if (i >= 4) positions.forEach((position, slot) => { if (position !== null && slot >= 4) next[position] = slot; });
    shown = next;
  });
}
// Shift and an encoder press, for a synth with a Shift row: Shift holds the row in the
// header, and a press switches pages with Shift held or not, as on the device, so
// the row shown follows the page.
if (shiftControls.length) {
  const encoders = document.createElement('div');
  encoders.className = 'segmented';
  encoders.setAttribute('aria-label', 'Encoders');
  encoders.innerHTML = '<button id="shift-hold" aria-pressed="false">Shift</button><button id="encoder-press">Press</button>';
  document.querySelector('.screen-toolbar').insertBefore(encoders, document.querySelector('.zoom-label'));
  $('shift-hold').addEventListener('click', () => { shiftHeld = !shiftHeld; update(); });
  $('encoder-press').addEventListener('click', () => {
    shown = pressedShown(shown, positions, 0, previewManifest.definition.press === 'page');
    update();
    status(`Page ${shown.some(s => s >= 4) ? 2 : 1}${shiftHeld ? ' · Shift row' : ''}`);
  });
}
// A drum kit's model, chosen on the device with Shift.
let model = 0;
const models = previewManifest.definition?.resources?.modelCount ?? 0;
if (models) {
  const item = document.createElement('div');
  item.className = 'control';
  item.innerHTML = `<label for="drum-model">Shift / Model</label><output id="value-drum-model">1</output><input id="drum-model" type="range" min="0" max="${models - 1}" step="1" value="0" aria-label="Model">`;
  $('controls').append(item);
  $('drum-model').addEventListener('input', event => { model = Number(event.target.value); update(); });
}
for (const [name, preset] of Object.entries(presets)) {
  const button = document.createElement('button');
  button.textContent = name;
  button.addEventListener('click', () => { values = { ...preset }; update(); status(`${name} loaded`); });
  $('presets').append(button);
}
function draw(elapsed = 0) {
  if (display) {
    const words = parameterWords();
    const input = shownControls(words.slice(0, 8), shown);
    // A synth's Shift row: held while the preview shows it, on the page the encoders are on.
    const row = shiftControls.length ? { held: shiftHeld ? 1 : 0, line: shown.some(s => s >= 4) ? 1 : 0, values: words.slice(8) } : null;
    try {
      scene.apply(display.tick(input, elapsed, visualNotes, 0, reducedMotion.matches, noteActivity, model, 0, [0, 0, 0, 0],
                               null, { pan: 0, level: 0 }, 0, row));
    }
    catch (error) { display = scene = displayBackend = null; status(`Display stopped: ${error.message}`); }
  }
  $('screen').innerHTML = renderScreen(values, view, samples, scene?.svg() || '');
}
async function loadPreview() {
  const manifest = previewManifest;
  const paths = ['/preview/engine.wasm', '/preview/panel.svg'];
  if (manifest.graphics.grayscale_sha256) paths.push('/preview/panel.grayscale.svg');
  const responses = await Promise.all(paths.map(path => fetch(path)));
  if (responses.some(response => !response.ok)) throw new Error('Compiled preview or artwork is unavailable.');
  const [bytes, artwork, grayscale] = await Promise.all(responses.map(response => response.arrayBuffer()));
  const digestOf = async buffer => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', buffer)),
    byte => byte.toString(16).padStart(2, '0')).join('');
  const [digest, artDigest] = await Promise.all([digestOf(bytes), digestOf(artwork)]);
  if (digest !== manifest.wasm_sha256 || artDigest !== manifest.graphics.asset_sha256) throw new Error('Preview identity mismatch.');
  if (grayscale && await digestOf(grayscale) !== manifest.graphics.grayscale_sha256) throw new Error('Grayscale preview identity mismatch.');
  const choice = {artwork:new TextDecoder().decode(artwork), preview:{graphics:manifest.graphics}};
  if (grayscale) choice.grayscaleArtwork = new TextDecoder().decode(grayscale);
  const module = await WebAssembly.compile(bytes);
  const readyDisplay = new PreviewDisplay(module);
  const readyScene = new SvgDisplay(selectArtwork(choice, graphicsMode), manifest.graphics);
  artworkChoice = choice;
  $('graphics').disabled = false;
  display = readyDisplay;
  scene = readyScene;
  displayBackend = { backend: 'cpp-wasm', stateBytes: display.stateBytes, frameBytes: readyDisplay.frame.byteLength, wasmSha256: digest };
  draw();
  return { manifest, digest, module };
}
const graphicsSelect = createGraphicsSelector(next => {
  if (!artworkChoice || !display) return;
  try {
    const replacement = new SvgDisplay(selectArtwork(artworkChoice, next), previewManifest.graphics);
    scene = replacement; graphicsMode = next; draw();
    status(next === 'colorful' ? 'Original artwork' : artworkChoice.grayscaleArtwork ? 'Grayscale · developer artwork' : 'Grayscale · automatic conversion');
  } catch (error) { graphicsSelect.value = graphicsMode; status('Graphics unchanged: ' + error.message); }
});

let preview;
function update() {
  for (const p of [...parameters, ...shiftControls.map(({ p }) => p)]) {
    const id = controlId(p.id);
    $(id).value = values[p.id];
    $(id).setAttribute('aria-valuetext', displayValue(p.id, values));
    $(`knob-${id}`).setAttribute('aria-valuenow', values[p.id]);
    $(`knob-${id}`).setAttribute('aria-valuetext', displayValue(p.id, values));
    $(`value-${id}`).textContent = displayValue(p.id, values);
    $(`dial-${id}`).setAttribute('transform', `rotate(${-135 + 270 * values[p.id]} 30 30)`);
  }
  for (const button of $('presets').children) {
    button.setAttribute('aria-pressed', String(parameters.every(p => presets[button.textContent][p.id] === values[p.id])));
  }
  for (const mode of VIEWS) $(mode).setAttribute('aria-pressed', String(mode === view));
  if (shiftControls.length) $('shift-hold').setAttribute('aria-pressed', String(shiftHeld));
  send({ type: 'parameters', value: parameterWords() });
  if (models) { $('value-drum-model').textContent = String(model + 1); send({ type: 'model', value: model }); }
  draw();
}
async function enableAudio() {
  if (starting) return starting;
  starting = (async () => {
    status('Starting audio…');
    try {
      if (!context) {
        // Create/resume on the input gesture, before awaiting compilation or the worklet.
        context = new AudioContext({ latencyHint: 'interactive', sampleRate: previewManifest.sample_rate });
        if (context.sampleRate !== previewManifest.sample_rate) throw new Error('Browser cannot provide the kernel sample rate.');
        const [{ manifest, digest, module }] = await Promise.all([preview, context.resume()]);
        await context.audioWorklet.addModule('/harness/processor.mjs');
        processor = new AudioWorkletNode(context, 'opxy-engine', { numberOfInputs: 0, numberOfOutputs: 1,
          outputChannelCount: [new WebAssembly.Instance(module).exports.opxy_output_channels?.() ?? 1],
          processorOptions: { module, parameters: parameterWords() } });
        const ready = new Promise((resolve, reject) => {
          const timeout = setTimeout(() => reject(new Error('Audio processor did not start.')), 5000);
          processor.onprocessorerror = () => {
            clearTimeout(timeout); reject(new Error('Audio processor failed.'));
            audioBackend = null; panic(); status('Audio processor stopped. Reload to retry.');
          };
          processor.port.onmessage = ({ data }) => {
            if (data.ready) {
              clearTimeout(timeout); audioBackend = { ...data, wasmSha256: digest }; resolve();
            }
            if (data.error) status(data.error);
          };
        });
        gain = context.createGain(); gain.gain.value = Number($('monitor').value);
        muteGain = context.createGain();
        outputMute.attach(muteGain.gain, context);
        analyser = context.createAnalyser(); analyser.fftSize = 1024;
        samples = new Float32Array(analyser.fftSize);
        processor.connect(gain).connect(analyser).connect(muteGain).connect(context.destination);
        const activeContext = context;
        context.onstatechange = () => {
          if (context !== activeContext) return;
          if (context.state !== 'running') panic();
        };
        send({ type: 'parameters', value: parameterWords() });
        if (models) send({ type: 'model', value: model });
        await Promise.all([context.resume(), ready]);
      }
      await context.resume();
      status(playbackStatus());
      return true;
    } catch (error) {
      if (context) await context.close().catch(() => {});
      outputMute.detach();
      context = processor = gain = muteGain = analyser = samples = null;
      audioBackend = null;
      status(`Audio unavailable: ${error.message}`);
      return false;
    }
  })();
  try { return await starting; } finally { starting = null; }
}
function paintKeys() {
  for (let i = 0; i < keys.length; i++) {
    const active = [...held.values()].includes((octave + 1) * 12 + i);
    $(`key-${i}`).classList.toggle('active', active);
    $(`key-${i}`).setAttribute('aria-pressed', String(active));
  }
}
function noteOn(source, note, velocity = 0.8) {
  if (!Number.isInteger(note) || note < 0 || note > 127 || !Number.isFinite(velocity) || velocity <= 0 || velocity > 1) return false;
  if (context?.state !== 'running' || !audioBackend) { status('Play a key or phrase to start audio.'); return false; }
  if (held.has(source)) return false;
  const existing = [...held.values()].includes(note);
  held.set(source, note);
  if (!existing) {
    send({ type: 'on', note, velocity });
    noteActivity.noteOn(note);
    visualNotes = (visualNotes + 1) >>> 0;
    draw();
  }
  paintKeys();
  return true;
}
function playKey(source, note) {
  return activation.run(source, () => noteOn(source, note));
}
function noteOff(source) {
  activation.cancel(source);
  const note = held.get(source);
  held.delete(source);
  if (note !== undefined && ![...held.values()].includes(note)) {
    send({ type: 'off', note });
    noteActivity.noteOff(note);
    draw();
  }
  paintKeys();
}
function panic() {
  activation.cancelAll();
  for (const timer of timers) clearTimeout(timer);
  timers.clear(); held.clear(); send({ type: 'panic' });
  noteActivity.panic(); draw();
  paintKeys(); $('phrase').textContent = 'Play phrase';
}
for (const [i, key] of keys.entries()) {
  const button = document.createElement('button');
  button.id = `key-${i}`; button.className = `key ${black.has(i) ? 'black' : 'white'}`;
  button.textContent = key.toUpperCase();
  button.setAttribute('aria-label', `Play semitone ${i}, keyboard ${key.toUpperCase()}`);
  button.addEventListener('pointerdown', event => {
    event.preventDefault(); button.blur(); button.setPointerCapture(event.pointerId);
    playKey(`pointer-${event.pointerId}`, (octave + 1) * 12 + i);
  });
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) button.addEventListener(type, event => noteOff(`pointer-${event.pointerId}`));
  button.addEventListener('keydown', event => {
    if ([' ', 'Enter'].includes(event.key)) { event.preventDefault(); if (!event.repeat) playKey(`button-${i}`, (octave + 1) * 12 + i); }
  });
  button.addEventListener('keyup', event => { if ([' ', 'Enter'].includes(event.key)) noteOff(`button-${i}`); });
  button.addEventListener('blur', () => noteOff(`button-${i}`));
  $('keyboard').append(button);
}
window.addEventListener('keydown', event => {
  if (event.key === 'Escape') { panic(); return; }
  if (event.ctrlKey || event.metaKey || event.altKey || event.repeat || /INPUT|SELECT|TEXTAREA/.test(event.target.tagName)) return;
  const i = keys.indexOf(event.key.toLowerCase());
  if (i >= 0) { event.preventDefault(); playKey(`key-${event.code}`, (octave + 1) * 12 + i); }
});
window.addEventListener('keyup', event => noteOff(`key-${event.code}`));
window.addEventListener('blur', panic);
document.addEventListener('visibilitychange', () => { if (document.hidden) panic(); });
$('audio').addEventListener('click', () => {
  outputMute.toggle();
  renderMuteButton();
  status(playbackStatus());
});
$('panic').addEventListener('click', () => { panic(); status('All notes stopped'); });
$('monitor').addEventListener('input', () => gain?.gain.setTargetAtTime(Number($('monitor').value), context.currentTime, 0.01));
for (const mode of VIEWS) $(mode).addEventListener('click', () => { view = mode; update(); });
$('zoom').addEventListener('change', () => $('frame').classList.toggle('native', $('zoom').value === 'native'));
for (const [id, direction] of [['octave-down', -1], ['octave-up', 1]]) $(id).addEventListener('click', () => {
  panic(); octave = Math.max(1, Math.min(7, octave + direction)); $('octave-label').textContent = `C${octave}–C${octave + 1}`;
});
function later(callback, ms) {
  const timer = setTimeout(() => { timers.delete(timer); callback(); }, ms); timers.add(timer);
}
$('phrase').addEventListener('click', () => {
  if (timers.size || activation.isPending(phraseRequest)) { panic(); return; }
  $('phrase').textContent = 'Stop phrase';
  activation.run(phraseRequest, () => {
    panic(); $('phrase').textContent = 'Stop phrase';
    [0, 7, 12, 3, 10, 7, 2, 0].forEach((offset, i) => {
      later(() => noteOn(`phrase-${i}`, (octave + 1) * 12 + offset), i * 280);
      later(() => noteOff(`phrase-${i}`), i * 280 + 220);
    });
    later(() => { $('phrase').textContent = 'Play phrase'; }, 2240);
  }).then(started => {
    if (!started && !timers.size && !activation.isPending(phraseRequest)) $('phrase').textContent = 'Play phrase';
  });
});
function download(name, body, type) {
  const url = URL.createObjectURL(new Blob([body], { type }));
  const anchor = document.createElement('a'); anchor.href = url; anchor.download = name; anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
$('export').addEventListener('click', () => download(`${definition.id}.patch.json`, JSON.stringify(makePatch(values, view), null, 2) + '\n', 'application/json'));
$('svg').addEventListener('click', () => download(`${definition.id}.screen.svg`, renderScreen(values, view, samples, scene?.svg() || ''), 'image/svg+xml'));
$('import').addEventListener('click', () => $('file').click());
$('file').addEventListener('change', async () => {
  const file = $('file').files[0];
  if (!file) return;
  try {
    if (file.size > 16384) throw new Error('Patch exceeds 16 KB.');
    const patch = readPatch(JSON.parse(await file.text()));
    panic(); values = patch.parameters; view = patch.view; update(); status('Patch imported');
  } catch (error) { status(`Import rejected: ${error.message}`); }
  finally { $('file').value = ''; }
});
$('reset').addEventListener('click', () => { panic(); values = defaults(); shown = [0, 1, 2, 3]; shiftHeld = false; update(); status('Controls reset'); });
// Stable local automation surface: uses the same validation and note lifecycle as UI.
window.machineLab = Object.freeze({
  getPatch: () => makePatch(values, view),
  loadPatch: patch => { const p = readPatch(patch); panic(); values = p.parameters; view = p.view; update(); },
  setParameters: next => { values = validateParameters(next); update(); },
  noteOn: (note, velocity = 0.8) => noteOn(`api-${note}`, note, velocity),
  noteOff: note => noteOff(`api-${note}`), panic,
  getStatus: () => ({ audio: context?.state || 'off', muted: outputMute.muted, heldNotes: held.size, sampleRate: context?.sampleRate || null,
    audioBackend, displayBackend,
    visualNotes, noteActivity: { held_notes: display?.input[17] ?? null, note_off_serial: display?.input[18] ?? null },
    rms: !outputMute.muted && samples ? Math.sqrt(samples.reduce((sum, x) => sum + x * x, 0) / samples.length) : 0 }),
});
update();
preview = loadPreview();
preview.catch(error => status(`Preview unavailable: ${error.message}`));
reducedMotion.addEventListener('change', () => draw());
let lastFrame = 0;
function animate(time) {
  if (!document.hidden && time - lastFrame > 32) {
    const elapsed = Math.min(8192, Math.max(0, Math.round((time - lastFrame) * 1.024)));
    lastFrame = time;
    if (analyser && context?.state === 'running') analyser.getFloatTimeDomainData(samples);
    else samples?.fill(0);
    if (view === 'waveform' || !reducedMotion.matches) draw(elapsed);
  }
  requestAnimationFrame(animate);
}
requestAnimationFrame(animate);
