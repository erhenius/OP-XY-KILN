// Stock OS 1.2.1 side of note players. Stock dispatches player types 2..4
// (Arpeggio, Hold, Maestro) from a branch tree and keeps one UI controller per
// type in a five-entry table. A player of the collection is built by the stock
// factory as a Maestro (type 4) and then takes its own method table, so the
// stock step and release play its chords and the Maestro page and controller
// edit its parameters. Its routing mode is fixed independently of those
// parameters. The hooks (player_hooks.s) ask these functions:
//   factory 8d57ee6c   build an owned type
//   load    8d588d94   keep an owned type a project stored
//   UI      8c0af13a, 8c0af43e  index the controller table with Maestro's entry
//   turn    8c084d18   edit the parameter an encoder shows
//   click   8c084e14   keep Maestro's encoder 4 click from a paged player
//   names   8d5bddd8, 8d5bde60  convert between an owned type and its name
#include "keyboard_octaves.hpp"
#include "players.hpp"
#include "player_activity.hpp"
#include "player_plans.hpp"
#include "player_controls.hpp"
#include "registration.hpp"

extern "C" {
void* sdk_player_build(opxy::u32 track, opxy::u32 type, opxy::u32 flag) __asm__("sdk_player_build");
opxy::u32 sdk_player_keep(opxy::u32 type) __asm__("sdk_player_keep");
opxy::u32 sdk_player_ui_type() __asm__("sdk_player_ui_type");
const char* sdk_player_name(opxy::u32 type) __asm__("sdk_player_name");
opxy::u32 sdk_player_id(const void* name) __asm__("sdk_player_id");
opxy::u32 sdk_player_substitute(opxy::u32 selected) __asm__("sdk_player_substitute");
opxy::u32 sdk_player_turn(opxy::u32 index, const opxy::i32* event) __asm__("sdk_player_turn");
opxy::u32 sdk_player_click() __asm__("sdk_player_click");
extern opxy::u32 (*sdk_screen_substitute)(opxy::u32) __asm__("sdk_screen_substitute");
// The one press dispatch (synth_controls.cpp): a click of encoder 0..3 on the player page.
extern void (*sdk_player_press)(opxy::u32) __asm__("sdk_player_press");
}

namespace opxy { namespace platform {
namespace {
using registry::StockString;
using opxy::player::Plan;

const u32 kFactory = 0x8d57ee6c;       // (track, type, flag) -> object or null
const u32 kSelectedType = 0x8d57efb8;  // the selected track's live or stored type
const u32 kParameters = 0x8d5863d8;    // (track) -> the track's eight parameter words
const u32 kArpeggio = 2, kMaestro = 4, kStockTypes = 5;
const u32 kPlayers = 0x84efc768;       // each track's player object, or null
const u32 kPlayerSlots = 16;           // one per track
const u32 kMaestroPage = 46;           // the stock Maestro page (chord.svg)
const u32 kContinue = 0xffffffffu;

// OS 1.2.1 Maestro object fields: chord records from +0x10c, count at +0x34c.
// A record's tone plays when its delay, decremented every step, reaches zero;
// release sends note-off for every played tone when the record's root matches.
typedef PlayerChord ChordRecord;
const u32 kRecords = 0x10c, kHeld = 0x34c, kMaxHeld = 8;
static_assert(kRecords + kMaxHeld * sizeof(ChordRecord) == kHeld, "Stock Maestro chord array layout");
// Each track's player lives in its own 64 KiB slot; stock objects end below
// 0x480, so the SDK state follows at a fixed offset.
const u32 kStateOffset = 0x800;
static_assert(kStateOffset + opxy::player::state_bytes <= 0x10000, "Player state exceeds the stock slot");
// The GUI-written input (shift row, Shift turns, clicks) follows State.
const u32 kInputOffset = kStateOffset + opxy::player::state_bytes;
static_assert(kInputOffset + sizeof(PlayerInput) <= 0x10000, "Player input exceeds the stock slot");

// Published by the GUI once per compositor frame (sdk_player_substitute):
// whether Shift is held, and the page stock selected.
volatile u32 shift_published, page_selected;

char* bytes(void* object) { return static_cast<char*>(object); }

const Player* owned(u32 type) {
    for (u32 i = 0; i < sdk_player_count; ++i) {
        const Player* p = sdk_players[i].player();
        if (p && p->type() == type) return p;
    }
    return nullptr;
}

// The first parameter each track's page shows, 0 or 4. A player starts on its
// first page whenever it is built.
u8 rows[kTracks];

// The selected track's player when a press switches its page: a paged player
// whose own page is in place. Stock places a page at GUI startup when its slot
// is free; one it did not place leaves stock's Maestro page, which shows only
// the first four, so such a player keeps one page: its press switches nothing,
// encoder 4's click stays stock's and its encoders edit the first four.
const Player* paged(u32 track) {
    const Player* p = track < kTracks ? owned(stock<u32()>(kSelectedType)()) : nullptr;
    return p && p->paged && p->page_ready && p->page_ready() == 1 ? p : nullptr;
}

// Counts a click of encoder 0..3 (stock records only clicks released without a
// turn and without Shift) for the selected track's player while the last frame
// selected the Maestro page, which its own page replaces.
void count_click(u32 encoder) {
    if (encoder >= 4 || page_selected != kMaestroPage) return;
    const Player* p = owned(stock<u32()>(kSelectedType)());
    const u32 track = selected_track();
    if (!p || track >= kTracks) return;
    if (void* object = player_object(track, p->vtable)) {
        volatile PlayerInput* input = player_input(object);
        input->clicks[encoder] = static_cast<opxy::u8>(input->clicks[encoder] + 1);
    }
}

// A click of any encoder on the player page (synth_controls.cpp), the one press
// dispatch: a paged player's press switches its page and is taken; any other
// player's is counted in its clicks. Stock still receives the click (on encoder
// 4, outside a paged player, its toggle of parameter 3: the click hook below).
void press(u32 encoder) {
    const u32 track = selected_track();
    if (paged(track)) rows[track] ^= 4;
    else count_click(encoder);
}

bool equal(const StockString* string, const char* name) {
    u32 length = 0;
    while (name[length]) ++length;
    if (string->length != length || string->capacity < length) return false;
    const char* text = string->text;
    if (string->capacity >= 16) __builtin_memcpy(&text, string->text, sizeof text);
    if (!text) return false;
    for (u32 i = 0; i < length; ++i)
        if (text[i] != name[i]) return false;
    return true;
}
}

void* player_state(void* object) { return bytes(object) + kStateOffset; }
volatile PlayerInput* player_input(void* object) {
    return reinterpret_cast<volatile PlayerInput*>(bytes(object) + kInputOffset);
}

void* player_object(u32 track, const void* const* vtable) {
    if (track >= kPlayerSlots) return nullptr;
    void* object = *reinterpret_cast<void* const volatile*>(kPlayers + 4 * track);
    return object && *static_cast<const void* const* const*>(object) == vtable ? object : nullptr;
}

// GUI startup registers every player's page (each player has one). The hooks
// that publish Shift and the selected page each frame and dispatch encoder
// presses are installed whether or not the page was placed: every player's
// Controls carry Shift and clicks, the substitute offers a page only once it is
// ready, and a press pages only a page that is in place (paged()).
int register_player_page(const Record* record, const Screen* screen) {
    sdk_screen_substitute = sdk_player_substitute;
    sdk_player_press = press;
    return sdk_register_screen(record, screen);
}

u32 player_row(u32 track) { return track < kTracks ? rows[track] : 0; }

opxy::player::Controls player_controls(void* object) {
    const u32 track = *reinterpret_cast<const u32*>(bytes(object) + 4);
    const i32* words = stock<const i32*(u32)>(kParameters)(track);
    opxy::player::Controls controls;
    for (u32 i = 0; i < 8; ++i) controls.value[i] = words[i];
    const i32 octave = track < kTracks ? sdk_track_octaves[track] : 0;
    controls.lowest_key = static_cast<u32>(static_cast<i32>(kLowestKey) + 12 * octave);
    controls.bpm_x10 = audio_bpm_x10();  // the audio clock's tempo word; safe on any role
    controls.shift = shift_published;
    const volatile PlayerInput* input = player_input(object);
    for (u32 i = 0; i < 8; ++i) {
        controls.shift_value[i] = input->shift_value[i];
        controls.shift_turns[i] = input->shift_turns[i];
    }
    for (u32 i = 0; i < 4; ++i) controls.clicks[i] = input->clicks[i];
    return controls;
}

void play_plan(void* object, u32 root, const Plan& plan) {
    volatile u32& held = *reinterpret_cast<volatile u32*>(bytes(object) + kHeld);
    if (!plan.count) return;  // silent input must not alter an existing root
    player_store(reinterpret_cast<ChordRecord*>(bytes(object) + kRecords), held,
        root, plan, false, false, [object](u32 note) { stock<void(void*, u32)>(kMaestroRelease)(object, note); });
}

void update_plan(void* object, const opxy::player::Update& update) {
    if (update.mode != opxy::player::Replace && update.mode != opxy::player::Add) return;
    volatile u32& held = *reinterpret_cast<volatile u32*>(bytes(object) + kHeld);
    player_store(reinterpret_cast<ChordRecord*>(bytes(object) + kRecords), held,
        update.root, update.plan, true, update.mode == opxy::player::Add,
        [object](u32 note) { stock<void(void*, u32)>(kMaestroRelease)(object, note); });
}

void player_output(void* object, opxy::player::Display& display) {
    const u32 held = *reinterpret_cast<const volatile u32*>(bytes(object) + kHeld);
    player_activity(reinterpret_cast<const volatile PlayerChord*>(bytes(object) + kRecords), held, display.played);
    display.lowest_key = player_controls(object).lowest_key;
}
}}

using namespace opxy::platform;
using opxy::u32;

// An owned type becomes a stock Maestro without the selection flag, which
// would reset the track's recorded Maestro chord, then takes its own methods.
void* sdk_player_build(u32 track, u32 type, u32) {
    const Player* p = owned(type);
    if (!p) return reinterpret_cast<void*>(kContinue);
    void* object = stock<void*(u32, u32, u32)>(kFactory)(track, kMaestro, 0);
    if (object) {
        __builtin_memset(player_state(object), 0, opxy::player::state_bytes);
        volatile PlayerInput* input = player_input(object);
        for (u32 i = 0; i < 8; ++i) {
            input->shift_value[i] = p->shift && i < p->shift->count ? p->shift->defaults[i] : 0;
            input->shift_turns[i] = 0;
        }
        for (u32 i = 0; i < 4; ++i) input->clicks[i] = 0;
        *static_cast<const void* const**>(object) = p->vtable;
        if (track < kTracks) rows[track] = 0;
    }
    return object;
}

// Stock replaces a loaded type of 1 or at least 5 with Arpeggio.
u32 sdk_player_keep(u32 type) { return owned(type) != nullptr; }

// An owned type uses Maestro's controller. Any other type outside the stock
// table uses Arpeggio's, as a loaded project would.
u32 sdk_player_ui_type() {
    const u32 type = stock<u32()>(kSelectedType)();
    if (type < kStockTypes) return type;
    return owned(type) ? kMaestro : kArpeggio;
}

// Maestro's GUI turn handler supplies (controller, index, event). The turn
// shim preserves it for stock unless an owned player takes the turn. All
// owned turns bypass Maestro's post-edit hold-mode callback: parameter 3 is
// a machine control, never stock's hold-mode switch.
// event[1] is signed detents; event[0] is continuous motion. Stock's setter
// updates the live parameter and the saved pattern, including dirty state.
// On a paged player's second page the encoders edit parameters 4..7, which
// stock's setter and continuous editor store as they do the first four.
//
// With Shift held, a player with a shift row takes every turn that reaches
// here (index 0..3, or 4..7 should stock pass Shift's row so). As a synth's
// Shift row, entry row + k sits under encoder k of the page shown (row 0 or 4):
// the turn edits that shift control and adds its detents to its shift_turns
// word, in the input beside State. Whether stock's Maestro controller reaches
// this hook while Shift is held has not been observed on a device. Without a
// shift row, or without Shift, turns are handled as before.
u32 sdk_player_turn(u32 index, const opxy::i32* event) {
    if (index >= 8 || !event) return 0;
    const Player* p = owned(stock<u32()>(kSelectedType)());
    if (!p) return 0;
    const u32 track = selected_track();
    const u32 row = paged(track) ? player_row(track) : 0;
    // The shift row first: an absent main slot does not block Shift on its encoder.
    if (p->shift && track < kTracks && shift_held()) {
        if (void* object = player_object(track, p->vtable)) {
            const u32 k = row + (index & 3);
            volatile PlayerInput* input = player_input(object);
            input->shift_turns[k] = static_cast<opxy::i32>(static_cast<u32>(input->shift_turns[k]) +
                                                           static_cast<u32>(event[1]));
            if (k < p->shift->count && event[1])
                input->shift_value[k] = player_enum_turn(input->shift_value[k], p->shift->choices[k], event[1]);
            return 1;
        }
    }
    if (index >= 4) return 0;  // only Shift's row may come as 4..7
    const u32 slot = index + row;
    if (p->steps[slot] == 1) return 1;  // an absent slot: the encoder turns nothing
    if (track >= kTracks) return 0;
    const u32 inherited[8] = {128, 8, 0, 4}; // stock's doubled buckets; the second page is continuous
    const u32 choices = p->steps[slot] >= 2 ? p->steps[slot] : inherited[slot];
    if (!choices) {
        stock<void(u32, u32, const opxy::i32*)>(0x8d586538)(track, slot, event);
    } else if (event[1]) {
        const opxy::i32 value = stock<const opxy::i32*(u32)>(kParameters)(track)[slot];
        stock<void(u32, u32, opxy::i32)>(0x8d586474)(track, slot,
            player_enum_turn(value, choices, event[1]));
    }
    return 1;
}

// Maestro's key handler toggles parameter 3 and runs its hold-mode callback on
// an encoder 4 click. A paged player's click switches the page instead
// (press), and a player whose presses are its own clicks ("press": "click")
// has only the click (press counted it): stock's toggle would also flip the
// control under encoder 4 and undo what the player does with the click.
// Nonzero skips the toggle.
u32 sdk_player_click() {
    const u32 track = selected_track();
    if (paged(track)) return 1;
    const Player* p = track < kTracks ? owned(stock<u32()>(kSelectedType)()) : nullptr;
    return p && p->clicks ? 1 : 0;
}

const char* sdk_player_name(u32 type) {
    const Player* p = owned(type);
    return p ? p->name : nullptr;
}

u32 sdk_player_id(const void* name) {
    for (u32 i = 0; i < sdk_player_count; ++i) {
        const Player* p = sdk_players[i].player();
        if (p && equal(static_cast<const registry::StockString*>(name), p->name)) return p->type();
    }
    return kContinue;
}

// The compositor's substitute for the selected page: the own page of the
// selected track's player while the stock Maestro page is selected, else 0.
u32 sdk_player_substitute(u32 selected) {
    // The compositor calls once per GUI frame, even when the player page is
    // hidden. Sequenced players on unselected tracks need fresh octaves too,
    // and every player the Shift state (Controls.shift).
    refresh_keyboard_octaves();
    shift_published = shift_held() ? 1 : 0;
    page_selected = selected;
    if (selected != kMaestroPage) return 0;
    const u32 track = selected_track();
    for (u32 i = 0; i < sdk_player_count; ++i) {
        const Player* p = sdk_players[i].player();
        if (p && p->page && p->page_ready && player_object(track, p->vtable) && p->page_ready() == 1)
            return static_cast<u32>(reinterpret_cast<Address>(p->page));
    }
    return 0;
}
