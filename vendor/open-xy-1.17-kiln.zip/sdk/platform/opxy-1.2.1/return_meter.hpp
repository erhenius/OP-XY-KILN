// Optional return telemetry for native send effects, OS 1.2.1.
// The two processors exchange selected-track meter words via stock telemetry.
#pragma once
#include "stock.hpp"
namespace opxy { namespace platform { namespace return_meter {
struct Window { u32 peak, blocks, serial, last; };
// Only the opted-in adapter instantiates storage. Mode changes may reset the
// DSP state; the per-send peak window spans those changes until the next report.
template<class O> static inline Window& window_for(u32 slot) {
    static Window windows[2];
    return windows[slot-14];
}
static inline bool send_track(u32 t) { return t == 14 || t == 15; }
static inline void write_level(u32 track, u32 value) {
    stock<u32(u32,u32)>(0x8d4d666a)(track + 4, value);
}
static inline u32 magnitude(i32 x) {
    // One's complement of negatives is within one Q31 LSB of abs(INT_MIN).
    return static_cast<u32>(x < 0 ? ~x : x);
}
template<class O> static inline auto reset(O* o, u32 track, int)
    -> typename decltype(o->state)::ReturnMeterEnabled {
    if (send_track(track)) {window_for<O>(track)={};write_level(track,0);}
}
template<class O> static inline void reset(O*,u32,...) {}
template<class O> static inline auto publish(O* o,const i32* l,const i32* r,int)
    -> typename decltype(o->state)::ReturnMeterEnabled {
    if (!send_track(o->slot)) return;
    auto& w = window_for<O>(o->slot);
    for (unsigned j=3; j<64; j+=16) {
        const u32 a=magnitude(l[j]), b=magnitude(r[j]);
        if(a>w.peak) w.peak=a;
        if(b>w.peak) w.peak=b;
    }
    if (++w.blocks < 34) return;
    // Low bits carry freshness even for steady levels. Publish zero once at rest.
    const u32 value=(w.peak >> 8) ? ((w.peak & 0x7fffff00u) | (++w.serial & 255u)) : 0;
    if(value!=w.last) { write_level(o->slot,value); w.last=value; }
    w.blocks=0; w.peak=0;
}
template<class O> static inline void publish(O*,const i32*,const i32*,...) {}
template<class S> static inline auto receive(S& s,u32 track,int)
    -> decltype(s.accept_return_meter(u32()),void()) {
    s.accept_return_meter(send_track(track) ? word(0x080376e4u + 4*(track+4)) : 0);
}
template<class S> static inline void receive(S&,u32,...) {}
} } }
